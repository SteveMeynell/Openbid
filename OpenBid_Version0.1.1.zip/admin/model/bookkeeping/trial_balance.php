<?php
class ModelBookkeepingTrialBalance extends Model {
    
    
    
    
} // End of Model