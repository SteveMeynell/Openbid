<?php
class ModelBookkeepingTransaction extends Model {
    
    
    
    
} // End of Model