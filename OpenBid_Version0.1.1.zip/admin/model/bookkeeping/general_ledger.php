<?php
class ModelBookkeepingGeneralLedger extends Model {
    
    
    
    
} // End of Model