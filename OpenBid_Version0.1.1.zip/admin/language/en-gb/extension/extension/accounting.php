<?php
// Heading
$_['heading_title']    = 'Accounting Package';

// Text
$_['text_success']     = 'Success: You have modified the Accounting Package!';
$_['text_list']        = 'Accounting Package';

// Column
$_['column_name']      = 'Package Name';
$_['column_status']    = 'Status';
$_['column_action']    = 'Action';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify the Accounting Package!';