<?php
$_['heading_title']    = 'Featured Auction Fee';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']	   = 'Success: You have modified Featured Auction Fee!';
$_['text_edit']        = 'Edit Featured Fee';
$_['text_description']       =   'This fee will be charged to the seller who wants to be featured.';

// Entry
$_['entry_status']     = 'Status';
$_['entry_fee']         =   'Fee Amount';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Auction Feature Fees!';
