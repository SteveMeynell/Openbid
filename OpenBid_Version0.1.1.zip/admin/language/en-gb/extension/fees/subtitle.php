<?php
$_['heading_title']    = 'Subtitle Fee';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']	   = 'Success: You have modified Subtitle Fee!';
$_['text_edit']        = 'Edit Subtitle Fee';
$_['text_description']       =   'Description for subtitle fee.';

// Entry
$_['entry_status']     = 'Status';
$_['entry_fee']         =   'Fee Amount';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Subtitle Fees!';
