<?php
$_['heading_title']    = 'Relist Fee';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']	   = 'Success: You have modified Relist Fee!';
$_['text_edit']        = 'Edit Relist Fee';
$_['text_description']       =   'Enter Fee to relist the auction.';

// Entry
$_['entry_status']     = 'Status';
$_['entry_fee']         =   'Fee Amount';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Relist Fees!';
