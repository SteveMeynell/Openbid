<?php
$_['heading_title']    = 'Carousel Fee';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']	   = 'Success: You have modified Carousel Fee!';
$_['text_edit']        = 'Edit Carousel Fee';
$_['text_description']       =   'Enter Fee to charge the seller to put the auction in the carousel.';

// Entry
$_['entry_status']     = 'Status';
$_['entry_fee']         =   'Fee Amount';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Carousel Fees!';
