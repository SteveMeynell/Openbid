<?php
$_['heading_title']    = 'Highlighted Fee';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']	   = 'Success: You have modified Highlighted Fee!';
$_['text_edit']        = 'Edit Highlight Fee';
$_['text_description']       =   'Enter Fee to highlight the auction.';

// Entry
$_['entry_status']     = 'Status';
$_['entry_fee']         =   'Fee Amount';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Highlight Fees!';
