<?php
$_['heading_title']    = 'Auction Setup Fee';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']	   = 'Success: You have modified Auction Setup Fee!';
$_['text_edit']        = 'Edit Auction Setup Fee';
$_['text_description']       =   'Enter Fee to charge for setting up an auction.';

// Entry
$_['entry_status']     = 'Status';
$_['entry_fee']         =   'Fee Amount';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Auction Setup Fees!';
