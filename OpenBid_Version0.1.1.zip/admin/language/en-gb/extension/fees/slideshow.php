<?php
$_['heading_title']    = 'Slideshow Fee';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']	   = 'Success: You have modified Slideshow Fee!';
$_['text_edit']        = 'Edit Slideshow Fee';
$_['text_description']       =   'Enter Fee to allow seller to put the auction in the slideshow.';

// Entry
$_['entry_status']     = 'Status';
$_['entry_fee']         =   'Fee Amount';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Slideshow Fees!';
