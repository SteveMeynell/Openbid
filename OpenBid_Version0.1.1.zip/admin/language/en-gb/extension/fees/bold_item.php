<?php
$_['heading_title']    = 'Bold Item Fee';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']	   = 'Success: You have modified Bold Item Fee!';
$_['text_edit']        = 'Edit Bold Item Fee';
$_['text_description']       =   'Enter Fee to Bold the item being auctioned.';

// Entry
$_['entry_status']     = 'Status';
$_['entry_fee']         =   'Fee Amount';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Bold Item Fees!';
