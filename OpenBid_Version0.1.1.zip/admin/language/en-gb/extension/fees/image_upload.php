<?php
$_['heading_title']    = 'Image Upload Fee';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']	   = 'Success: You have modified Image Upload Fee!';
$_['text_edit']        = 'Edit Image Upload Fee';
$_['text_description']       =   'Enter Fee to charge per image uploaded for the auction.';

// Entry
$_['entry_status']     = 'Status';
$_['entry_fee']         =   'Fee Amount';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Image Upload Fees!';
