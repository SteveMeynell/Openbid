<?php
$_['heading_title']    = 'Signup Fee';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']	   = 'Success: You have modified Site Signup Fee!';
$_['text_edit']        = 'Edit Signup Fee';
$_['text_description']       =   'Enter Fee to simply sign up for the website.';

// Entry
$_['entry_status']     = 'Status';
$_['entry_fee']         =   'Fee Amount';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Site Signup Fees!';
