<?php
$_['heading_title']    = 'Social Media Fee';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']	   = 'Success: You have modified Social Media Fee!';
$_['text_edit']        = 'Edit Social Media Fee';
$_['text_description']       =   'Enter Fee to charge for putting auctions on our social media sites, such as Facebook Page, Twitter etc.';

// Entry
$_['entry_status']     = 'Status';
$_['entry_fee']         =   'Fee Amount';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Social Media Fees!';
