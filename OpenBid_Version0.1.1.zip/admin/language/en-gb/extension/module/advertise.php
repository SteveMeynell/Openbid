<?php
// Heading
$_['heading_title']    = 'Advertisement';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Advertisement module!';
$_['text_edit']        = 'Edit Advertisement Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify advertisement module!';
$_['error_advertise']   =   'WARNING: Admin Error in advertise';