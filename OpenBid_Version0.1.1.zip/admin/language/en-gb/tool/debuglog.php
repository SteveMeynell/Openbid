<?php
// Heading
$_['heading_title']	   = 'Debug Log';

// Text
$_['text_success']	   = 'Success: You have successfully cleared your debug log!';
$_['text_list']        = 'Errors List';
//$_['text_debuglog']     =   'Debugging Log';

// Error
$_['error_warning']	   = 'Warning: Your error log file %s is %s!';
$_['error_permission'] = 'Warning: You do not have permission to clear debug log!';