<?php
$_['paypal_balance'] = 'PayPal Balance';
?>